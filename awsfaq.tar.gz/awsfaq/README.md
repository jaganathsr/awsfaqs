# JsonFile Task Agent

If you have a dialogue, QA or other text-only dataset that you can put in a text file in the format we will now describe, you can just load it directly from there, with no extra code!

E.g. use with: 

python parlai/scripts/display_data.py -t jsonfile --jsonfile-datapath /tmp/data.json

See the file example_data.json in this directory for the format.