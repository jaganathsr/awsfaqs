#!/usr/bin/env python3

# Copyright (c) Facebook, Inc. and its affiliates.
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

from parlai.core.build_data import DownloadableFile
import parlai.core.build_data as build_data
import os

RESOURCES = [
    DownloadableFile(
        'https://raw.githubusercontent.com/jaganathsr/awsfaqs/main/awsfaqparlai.json',
        'train.json',
        '9a915d2d5d168cfa33ed9b0a4315a933817ef63462c697030090495c184977d3',
        zipped=False,
    ),
    DownloadableFile(
        'https://raw.githubusercontent.com/jaganathsr/awsfaqs/main/awsfaqparlai.json',
        'valid.json',
        '9a915d2d5d168cfa33ed9b0a4315a933817ef63462c697030090495c184977d3',
        zipped=False,
    ),
    DownloadableFile(
        'https://raw.githubusercontent.com/jaganathsr/awsfaqs/main/awsfaqparlai.json',
        'test.json',
        '9a915d2d5d168cfa33ed9b0a4315a933817ef63462c697030090495c184977d3',
        zipped=False,
    ),

]


def build(opt):
    dpath = os.path.join(opt['datapath'], 'awsfaq')
    version = None

    if not build_data.built(dpath, version_string=version):
        print('[building data: ' + dpath + ']')
        # An older version exists, so remove these outdated files.
        if build_data.built(dpath):
            build_data.remove_dir(dpath)
        build_data.make_dir(dpath)

        # Download the data.
        for downloadable_file in RESOURCES:
            downloadable_file.download_file(dpath)

        # Mark the data as built.
        build_data.mark_done(dpath, version_string=version)
